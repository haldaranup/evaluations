function sidebar() {
  return `<h1>Masai News</h1>
    <input id="searchbar" type="text" placeholder="Search....">
    <p>Startups</p>
    <p>Newsletters</p>
    <p>Audio</p>
    <p>Video</p>`;

  // return your html component here
  //Make sure to give input search box id as ""
}
export default sidebar;
